package com.books;

public class Book {
	private String bookName;
	private String bookPrice;

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookName() {
		return this.bookName;
	}

	public void setBookPrice(String bookPrice) {
		this.bookPrice = bookPrice;
	}

	public String getBookPrice() {
		return this.bookPrice;
	}

}
