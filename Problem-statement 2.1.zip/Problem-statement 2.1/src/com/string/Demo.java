package com.string;

import java.util.*;

public class Demo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string: ");
		String s = sc.next();
		int length= s.length();
		System.out.println("Length of String: "+ length);
		
		// To UpperCase
		System.out.println("Upper case Of String: "+s.toUpperCase());
		
		// Check Palindrome
		
		String rev = "";	 
	      for ( int i = length - 1; i >= 0; i-- )
	         rev = rev + s.charAt(i);
	 
	      if (s.equals(rev))
	         System.out.println(s+" is a palindrome");
	      else
	         System.out.println(s+" is not a palindrome");
	}
}
