package com.arr;

import java.util.Arrays;

public class MergeSort {

	public static void main(String[] args) {
		int[] arr1 = new int[] { 5, 3, 8, 4, 7, 6 };
		int[] arr2 = new int[] { 12, 15, 41, 36, 79, 48 };
		System.out.println("arr1 [] = " + Arrays.toString(arr1));
		System.out.println("arr2 [] = " + Arrays.toString(arr2));
		int count1 = arr1.length;
		int count2 = arr2.length;
		int[] resArr = new int[count1 + count2];
		int i = 0, j = 0, k = 0;
		while (i < arr1.length) {
			resArr[k] = arr1[i];
			i++;
			k++;
		}
		while (j < arr2.length) {
			resArr[k] = arr2[j];
			j++;
			k++;
		}
		Arrays.sort(resArr);
		System.out.println("Merge List is  = " + Arrays.toString(resArr));

	}

}
