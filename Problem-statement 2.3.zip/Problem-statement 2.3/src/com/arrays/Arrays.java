package com.arrays;

public class Arrays {
	public static void main(String[] args) {
		int sum = 0;
		int a[]= {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		
		for (int i=0; i<=14; i++)
		{
			sum = sum+a[i];
		}
		
		System.out.println(sum);
 		int n=a.length;
		a[15]=sum;
		for(int i=0; i<=n-1; i++)
		{
		System.out.print(a[i]);
		
		}
		
		for (int i=0; i<=n-1; i++)
		{
			sum = sum+a[i];
		}
		a[16]=sum;
		for(int i=0; i<=n-1; i++)
		{
		System.out.println(a[i]);
		
		}
		
		int s=a[0];
		for (int i=0; i<=a.length-1; i++)
		{
			if (a[i]<s)
			s=a[i];
		}
		System.out.println("Smallest element: "+s);
		a[17]=s;
		for(int i=0; i<=n-1; i++)
		System.out.println(a[i]);
	}

}
