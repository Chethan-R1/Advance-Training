package com.string;

public class RotateString {
	public static void main(String[] args) {
		String s = "MPHASIS";
		int n = s.length();
		for (int i = 0; i < n; i++) {
			s = s.charAt(s.length() - 1) + s.substring(0, s.length() - 1);
			System.out.println(s);
		}

	}
}
