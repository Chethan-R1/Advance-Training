package com.rectangle;

public class Rectangle {
	double length;
	double breadth;
	
	Rectangle(double l, double b)
	{
		length = l;
		breadth = b;
	}

}
