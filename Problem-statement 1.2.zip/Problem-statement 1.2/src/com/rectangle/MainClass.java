package com.rectangle;

public class MainClass {
	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(3, 5);
		Rectangle r2 = new Rectangle(2.5, 8.4);
		Rectangle r3 = new Rectangle(8.9, 7.4);
		Rectangle r4 = new Rectangle(2.8, 4.4);
		Rectangle r5 = new Rectangle(6, 4);
		System.out.println("area of r1: "+ (r1.breadth*r1.length));
		System.out.println("area of r2: "+ (r2.breadth*r2.length));
		System.out.println("area of r3: "+ (r3.breadth*r3.length));
		System.out.println("area of r4: "+ (r4.breadth*r4.length));
		System.out.println("area of r5: "+ (r5.breadth*r5.length));
	}
}
