package com.finance;

public class BankAccount {
	protected int acno;
	protected float balance;

	public BankAccount(int a, int b) {
		acno = a;
		balance = b;
	}

	public void withdraw(int w) {
		balance -= w;
	}

	public void deposit(int d) {
		balance += d;
	}
}
