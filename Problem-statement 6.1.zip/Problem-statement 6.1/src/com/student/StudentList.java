package com.student;

import java.util.Scanner;

public class StudentList {
	public static String a[] = { "Ram", "James", "Raju", "Samson", "Ayesh" };
	public static int found = 0;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Student Name: ");
		String str = sc.nextLine();
		for (int i = 0; i < a.length; i++) {
			if (a[i].equals(str)) {
				found++;
			}
		}
		if (found > 0) {
			System.out.println("The student " + str + " is in the List");
		} else {
			System.out.println("The student " + str + " is not in the List");
		}
	}
}
