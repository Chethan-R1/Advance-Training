package com.music;

abstract class Instrument

{

	public abstract void Play();

}





