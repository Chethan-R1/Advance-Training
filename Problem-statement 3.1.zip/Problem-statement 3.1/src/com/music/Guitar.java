package com.music;

public class Guitar extends Instrument

{

	@Override
	public void Play()

	{

		System.out.println("Guitar is playing tin tin tin");

	}

}
