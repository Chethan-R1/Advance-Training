package com.rectangle;

public class Rectangle1 {

	public static void main(String[] args) {
		
		Rectangle  obj = new Rectangle();
		Rectangle obj1 = new Rectangle(4, 4);
		obj.printData();
		obj.printArea();
		obj.printPerimeter();


		obj1.printData();
		obj1.printArea();
		obj1.printPerimeter();
	}

}
