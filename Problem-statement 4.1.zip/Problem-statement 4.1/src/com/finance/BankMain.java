package com.finance;

public class BankMain {

	public static void main(String[] args) {
		Funds calculate = new Funds(123456789, 56000);
		calculate.accept(450, 670);

		calculate.compute();

		calculate.display();

	}

}
