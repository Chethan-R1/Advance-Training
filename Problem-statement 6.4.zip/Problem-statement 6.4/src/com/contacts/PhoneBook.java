package com.contacts;

import java.util.ArrayList;
import java.util.List;

public class PhoneBook {

	private static final List<Contact> Phone = null;
	private List<Contact> PhoneBook = new ArrayList<Contact>();

	public Contact viewContactGivenPhone(long phoneNumber) {
		Contact obj = new Contact();
		for (Contact obj1 : Phone) {
			if (obj1.getPhoneNumber() == phoneNumber) {
				obj = obj1;
			}
		}
		return obj;
	}

}