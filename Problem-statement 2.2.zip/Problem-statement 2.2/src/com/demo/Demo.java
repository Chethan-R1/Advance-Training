package com.demo;

import java.util.Scanner;

public class Demo {
	public static void main(String[] args) {

		int n = 13;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First number: ");
		int a = sc.nextInt();
		System.out.println("Enter Second number: ");
		int b = sc.nextInt();
		System.out.println("Number Series till " + n + " terms:");

		for (int i = 1; i <= n; ++i) {
			System.out.print(a + ", ");

			// compute the next term
			int nextTerm = a + b;
			a = b;
			b = nextTerm;
		}
	}
}
