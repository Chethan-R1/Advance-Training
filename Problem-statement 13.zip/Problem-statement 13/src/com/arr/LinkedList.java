package com.arr;

class LinkedList {
	Node head;

	class Node {
		int data;
		Node next;

		Node(int d) {
			data = d;
			next = null;
		}
	}

	void printNthFromLast(int n) {
		Node ptr1 = head;
		Node ptr2 = head;

		int count = 0;
		if (head != null) {
			while (count < n) {
				if (ptr2 == null) {
					System.out.println(-1);
					return;
				}
				ptr2 = ptr2.next;
				count++;
			}

			if (ptr2 == null) {
				head = head.next;
				if (head != null)
					System.out.println(n + "th node from the last is " + head.data);
			} else {

				while (ptr2 != null) {
					ptr1 = ptr1.next;
					ptr2 = ptr2.next;
				}
				System.out.println(+ptr1.data);
			}
		}

	}

	public void push(int new_data) {
		Node new_node = new Node(new_data);
		new_node.next = head;
		head = new_node;
	}

	public static void main(String[] args) {
		LinkedList llist = new LinkedList();
		llist.push(20);
		llist.push(4);
		llist.push(15);
		llist.push(35);
		llist.push(45);
		llist.push(74);
		llist.printNthFromLast(8);
	}
}
