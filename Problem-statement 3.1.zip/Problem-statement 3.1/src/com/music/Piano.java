package com.music;

public class Piano extends Instrument

{

	@Override
	public void Play()

	{

		System.out.println("Piano is playing tan tan tan tan");

	}

}